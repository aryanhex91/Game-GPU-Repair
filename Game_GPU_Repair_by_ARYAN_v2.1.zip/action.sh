#!/system/bin/sh
# Game GPU Repair - by @ARYAN._.HEX
# Usage: action.sh [angle|native|reset]   (no argument = use saved mode)
D=/sdcard/GameDriverRepair
C=$D/config.txt
LOG=$D/repair.log
mkdir -p $D

if [ ! -f $C ]; then
cat > $C <<'CFG'
# Game GPU Repair config - by @ARYAN._.HEX
# MODE:
#   reset  = only remove old driver overrides (safest)
#   angle  = use ANGLE (GLES-on-Vulkan layer) for the games below
#   native = force the stock system GPU driver for the games below
MODE=native
# 1 = clear the games' shader cache on every run, 0 = leave it alone
CLEAR_CACHE=1
# Package names separated by commas (no spaces)
GAMES=com.mojang.minecraftpe,com.tencent.ig,com.pubg.imobile,com.dts.freefireth,com.activision.callofduty.shooter,com.miHoYo.GenshinImpact,com.supercell.clashofclans
CFG
echo "Config created: $C"
echo "Edit MODE and GAMES there if you need to, then run again."
fi

# Mode passed from the WebUI: action.sh angle|native|reset
case "$1" in angle|native|reset) sed -i "s/^MODE=.*/MODE=$1/" $C;; esac

get() { grep "^$1=" $C | tail -n 1 | cut -d= -f2- | tr -d ' \r'; }
MODE=$(get MODE); [ -z "$MODE" ] && MODE=reset
CLEAR=$(get CLEAR_CACHE); [ -z "$CLEAR" ] && CLEAR=1
GAMES=$(get GAMES)
log() { echo "$(date '+%m-%d %H:%M:%S') $*" | tee -a $LOG; }
[ -f $LOG ] && [ "$(wc -c < $LOG)" -gt 20000 ] && : > $LOG

echo "  ◆ GAME GPU REPAIR  - @ARYAN._.HEX"; sleep 0.3
log "== Game GPU Repair | mode=$MODE | $(getprop ro.product.device) =="

# 1) Remove stale driver overrides (back to defaults)
for k in game_driver_all_apps game_driver_opt_in_apps game_driver_opt_out_apps \
         game_driver_prerelease_opt_in_apps game_driver_denylist game_driver_allowlist \
         updatable_driver_all_apps updatable_driver_production_opt_in_apps \
         updatable_driver_production_opt_out_apps updatable_driver_prerelease_opt_in_apps \
         updatable_driver_production_denylist updatable_driver_production_allowlist \
         angle_gl_driver_selection_pkgs angle_gl_driver_selection_values angle_debug_package; do
  settings delete global $k >/dev/null 2>&1
done
log "Stale driver settings reset"

# 2) Apply the selected mode
case "$MODE" in
  angle)
    if ls /system/lib64/libGLESv2_angle.so /system/lib64/egl/libGLESv2_angle.so /vendor/lib64/egl/libGLESv2_angle.so 2>/dev/null | grep -q . || pm list packages 2>/dev/null | grep -q com.android.angle; then
      VALS=""
      for g in $(echo "$GAMES" | tr ',' ' '); do VALS="$VALS${VALS:+,}angle"; done
      settings put global angle_gl_driver_selection_pkgs "$GAMES"
      settings put global angle_gl_driver_selection_values "$VALS"
      log "ANGLE enabled for: $GAMES"
    else
      log "ANGLE is not available on this ROM - skipped (overrides were only reset)"
    fi ;;
  native)
    VALS=""
    for g in $(echo "$GAMES" | tr ',' ' '); do VALS="$VALS${VALS:+,}native"; done
    settings put global angle_gl_driver_selection_pkgs "$GAMES"
    settings put global angle_gl_driver_selection_values "$VALS"
    log "Native driver forced for: $GAMES" ;;
  *) log "Mode is reset: no extra overrides applied" ;;
esac

# 3) Clear shader cache and stop the games
for g in $(echo "$GAMES" | tr ',' ' '); do
  [ -d /data/data/$g ] || continue
  if [ "$CLEAR" = "1" ]; then
    find /data/data/$g/code_cache -maxdepth 2 -iname '*shader*' -exec rm -rf {} + 2>/dev/null
    log "Shader cache cleared: $g"
  fi
  am force-stop $g
done
log "Done. Open your game again."
