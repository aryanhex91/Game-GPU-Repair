#!/system/bin/sh
bar() {
  ui_print "  $1"
  for p in 10 25 40 55 70 85 100; do
    n=$((p/10)); s=""; i=0
    while [ $i -lt 10 ]; do
      if [ $i -lt $n ]; then s="${s}█"; else s="${s}░"; fi
      i=$((i+1))
    done
    ui_print "  [$s] $p%"
    sleep 0.12
  done
}
ui_print ""
ui_print "  ╔══════════════════════════════════╗"; sleep 0.15
ui_print "  ║                                  ║"; sleep 0.15
ui_print "  ║      ◆  GAME GPU REPAIR  ◆       ║"; sleep 0.15
ui_print "  ║      ANGLE • Native • WebUI      ║"; sleep 0.15
ui_print "  ║                                  ║"; sleep 0.15
ui_print "  ╚══════════════════════════════════╝"; sleep 0.3
ui_print ""
ui_print "  ✦ Author  : @ARYAN._.HEX"; sleep 0.2
ui_print "  ✦ Version : v2.1"; sleep 0.2
ui_print "  ✦ Device  : $(getprop ro.product.device)"; sleep 0.2
ui_print "  ✦ GPU     : $(getprop ro.hardware.egl)"; sleep 0.2
ui_print "  ✦ Android : $(getprop ro.build.version.release)"; sleep 0.4
ui_print ""
bar "Scanning graphics stack..."
if ls /system/lib64/libGLESv2_angle.so /system/lib64/egl/libGLESv2_angle.so /vendor/lib64/egl/libGLESv2_angle.so 2>/dev/null | grep -q .; then
  ui_print "  ✔ ANGLE found"
else
  ui_print "  ! ANGLE not found (reset and native modes still work)"
fi
sleep 0.3
ui_print ""
bar "Preparing repair tools..."
ui_print "  ✔ Action + WebUI ready"
sleep 0.3
ui_print ""
bar "Setting permissions..."
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/action.sh 0 0 0755
ui_print ""
ui_print "  ╔══════════════════════════════════╗"
ui_print "  ║   ✔  INSTALLED SUCCESSFULLY      ║"
ui_print "  ║   ▶  Open WebUI to pick a mode   ║"
ui_print "  ╚══════════════════════════════════╝"
ui_print ""
ui_print "    Made with ♥ by @ARYAN._.HEX"
ui_print ""
sleep 0.5
